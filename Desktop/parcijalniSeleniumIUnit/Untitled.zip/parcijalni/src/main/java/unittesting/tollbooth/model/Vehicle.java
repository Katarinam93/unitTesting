package unittesting.tollbooth.model;

public abstract class Vehicle {
	public abstract double payToll();
}
