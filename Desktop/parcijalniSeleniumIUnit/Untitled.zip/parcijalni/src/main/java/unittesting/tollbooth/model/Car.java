package unittesting.tollbooth.model;

public class Car extends Vehicle {

	@Override
	public double payToll() {
		return 240;
	}

}
