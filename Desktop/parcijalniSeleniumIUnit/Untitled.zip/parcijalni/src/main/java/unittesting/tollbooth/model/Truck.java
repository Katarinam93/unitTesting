package unittesting.tollbooth.model;

public class Truck extends Vehicle {

	@Override
	public double payToll() {
		return 1000;
	}

}
