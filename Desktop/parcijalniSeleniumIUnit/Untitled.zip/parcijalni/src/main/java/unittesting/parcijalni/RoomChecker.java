package unittesting.parcijalni;

public class RoomChecker {

	public boolean isFree(Room room) {
		return true;
	}
}
